# Ressources d'apprentissage

Ces ressources permettent de donner aux nouveaux membres de la communauté QMK plus de compréhension aux informations données dans la documentation Newbs.

Ressources Git:

* [Tutoriel général](https://www.codecademy.com/learn/learn-git)
* [Jeu Git pour apprendre avec des exemples](https://learngitbranching.js.org/)
* [Des ressources Git pour en savoir plus à propos de GitHub](getting_started_github.md)
* [Des ressources Git spécifiques à QMK](contributing.md)

Ressources sur les lignes de commande:

* [Bon tutoriel général sur la ligne de commande](https://www.codecademy.com/learn/learn-the-command-line)
