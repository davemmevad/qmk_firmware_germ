# 学习资源

这些资源旨在让QMK社区的新成员更了解新成员文档中提供的信息。

Git 资源:

* [很好的通用教程](https://www.codecademy.com/learn/learn-git)
* [从例子中学习Git游戏](https://learngitbranching.js.org/)
* [了解有关GitHub的更多信息的Git资源](getting_started_github.md)
* [专门针对QMK的Git资源](contributing.md)


命令行资源:

* [超棒的命令行通用教程](https://www.codecademy.com/learn/learn-the-command-line)
