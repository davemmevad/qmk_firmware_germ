# Nick B's Super16 keymap

A modification of the default keymap to include layer indicators with RGB
* Added a time out of 3 seconds to 1 shot layers
* Reduced brightness to half to reduce power draw
* Added a one key copy/paste keycode  
