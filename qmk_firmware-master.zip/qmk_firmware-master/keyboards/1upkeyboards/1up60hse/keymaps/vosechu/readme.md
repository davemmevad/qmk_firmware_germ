# 1up60hse keymap made by vosechu

Tweaks from default

* Add in SpaceFN so arrows are reachable with just left hand (leaving right free for mousing).
* Also add tab/grv under the alt/ctrl keys to make those easier to reach.
